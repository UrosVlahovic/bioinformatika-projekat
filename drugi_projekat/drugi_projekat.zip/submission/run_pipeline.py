
import argparse
import os
import subprocess


def run(cmd):
    print("\n[RUN]", " ".join(cmd))
    subprocess.run(cmd, check=True)


def main():
    parser = argparse.ArgumentParser(description="FASTQ to filtered VCF pipeline")
    parser.add_argument("--r1", required=True, help="FASTQ file, read 1")
    parser.add_argument("--r2", required=True, help="FASTQ file, read 2")
    parser.add_argument("--ref", required=True, help="Reference FASTA")
    parser.add_argument("--outdir", required=True, help="Output directory")
    parser.add_argument("--gatk", default="gatk", help="Path to GATK executable")
    parser.add_argument("--threads", default="2", help="Number of threads")
    args = parser.parse_args()

    os.makedirs(args.outdir, exist_ok=True)

    fastqc_dir = os.path.join(args.outdir, "fastqc")
    os.makedirs(fastqc_dir, exist_ok=True)

    bam = os.path.join(args.outdir, "aligned.bam")
    sorted_bam = os.path.join(args.outdir, "aligned.sorted.bam")
    rg_bam = os.path.join(args.outdir, "aligned.rg.bam")

    raw_vcf = os.path.join(args.outdir, "raw_variants.vcf.gz")
    snps_vcf = os.path.join(args.outdir, "snps.vcf.gz")
    indels_vcf = os.path.join(args.outdir, "indels.vcf.gz")
    filtered_snps = os.path.join(args.outdir, "filtered_snps.vcf.gz")
    filtered_indels = os.path.join(args.outdir, "filtered_indels.vcf.gz")
    filtered_final = os.path.join(args.outdir, "filtered_variants_final.vcf.gz")
    pass_final = os.path.join(args.outdir, "pass_variants_final.vcf.gz")

    run(["fastqc", args.r1, args.r2, "-o", fastqc_dir])

    run(["bwa", "index", args.ref])
    run(["samtools", "faidx", args.ref])
    run([args.gatk, "CreateSequenceDictionary", "-R", args.ref])

    with open(bam, "wb") as out:
        bwa = subprocess.Popen(
            ["bwa", "mem", "-t", args.threads, args.ref, args.r1, args.r2],
            stdout=subprocess.PIPE
        )
        subprocess.run(["samtools", "view", "-@", args.threads, "-b"], stdin=bwa.stdout, stdout=out, check=True)
        bwa.stdout.close()
        bwa.wait()

    run(["samtools", "sort", "-@", args.threads, "-o", sorted_bam, bam])
    run(["samtools", "index", sorted_bam])

    run([
        args.gatk, "AddOrReplaceReadGroups",
        "-I", sorted_bam,
        "-O", rg_bam,
        "-RGID", "sample0",
        "-RGLB", "lib1",
        "-RGPL", "illumina",
        "-RGPU", "unit1",
        "-RGSM", "sample0"
    ])
    run(["samtools", "index", rg_bam])

    run([
        args.gatk, "HaplotypeCaller",
        "-R", args.ref,
        "-I", rg_bam,
        "-O", raw_vcf
    ])

    run([args.gatk, "SelectVariants", "-V", raw_vcf, "-select-type", "SNP", "-O", snps_vcf])
    run([args.gatk, "SelectVariants", "-V", raw_vcf, "-select-type", "INDEL", "-O", indels_vcf])

    run([
        args.gatk, "VariantFiltration",
        "-V", snps_vcf,
        "-O", filtered_snps,
        "--filter-name", "SNP_filter",
        "--filter-expression", "QD < 2.0 || FS > 60.0 || MQ < 40.0 || MQRankSum < -12.5 || ReadPosRankSum < -8.0"
    ])

    run([
        args.gatk, "VariantFiltration",
        "-V", indels_vcf,
        "-O", filtered_indels,
        "--filter-name", "INDEL_filter",
        "--filter-expression", "QD < 2.0 || FS > 200.0 || ReadPosRankSum < -20.0"
    ])

    run([args.gatk, "MergeVcfs", "-I", filtered_snps, "-I", filtered_indels, "-O", filtered_final])
    run(["bcftools", "view", "-f", "PASS", "-Oz", "-o", pass_final, filtered_final])
    run(["tabix", "-p", "vcf", pass_final])

    print("\nPipeline finished.")
    print("Filtered VCF:", filtered_final)
    print("PASS VCF:", pass_final)


if __name__ == "__main__":
    main()
