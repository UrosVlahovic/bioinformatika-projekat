
# Uvod u bioinformatiku - drugi domaci

## Opis

Ovaj projekat implementira pipeline za obradu FASTQ fajlova, mapiranje sekvenci na referentni genom, pozivanje varijanti i filtriranje varijanti.

Korisceni alati:

- FastQC
- BWA
- Samtools
- GATK
- bcftools
- Python

## Ulazni podaci

Korisceni FASTQ fajlovi:

- sample_0.chrom11.exome.pe1.fq.gz
- sample_0.chrom11.exome.pe2.fq.gz

FASTQ fajlovi nisu dodati u repozitorijum zbog velicine.

Referenca:
- chr11.fa (hg38)

Referenca nije dodata u repozitorijum.

## Pokretanje pipeline-a

Primer:

python run_pipeline.py --r1 sample_0.chrom11.exome.pe1.fq.gz --r2 sample_0.chrom11.exome.pe2.fq.gz --ref reference/chr11.fa --outdir output --gatk ./gatk --threads 2

Pipeline izvrsava:

1. FastQC
2. BWA MEM mapiranje
3. BAM konverziju
4. Sortiranje BAM fajla
5. Dodavanje read group informacija
6. HaplotypeCaller
7. SNP i INDEL izdvajanje
8. Hard filtering
9. Formiranje PASS VCF fajla

## Korisceni filteri

SNP:

QD < 2.0 || FS > 60.0 || MQ < 40.0 || MQRankSum < -12.5 || ReadPosRankSum < -8.0

INDEL:

QD < 2.0 || FS > 200.0 || ReadPosRankSum < -20.0

## Rezultati

Pre filtriranja:

- Ukupno varijanti: 16887
- SNP: 14858
- INDEL: 2034

Posle filtriranja:

- Ukupno varijanti: 16570
- SNP: 14624
- INDEL: 1946

Odbaceno varijanti:

- 317
- 1.88%

## Fajlovi

results/

- sample_0.chrom11.exome.pe1_fastqc.html
- sample_0.chrom11.exome.pe2_fastqc.html
- filtered_variants_final.vcf.gz
- pass_variants_final.vcf.gz
- metrics.json
- variant_comparison_final.png

## Nepredati fajlovi

- FASTQ
- BAM
- SAM
- referentni genom
- indeks fajlovi reference
- privremeni fajlovi
