
import argparse
import gzip
import json
from collections import Counter

import pandas as pd
import matplotlib.pyplot as plt


def open_vcf(path):
    if path.endswith(".gz"):
        return gzip.open(path, "rt")
    return open(path, "r")


def count_variants(vcf_path):
    counts = Counter()

    with open_vcf(vcf_path) as f:
        for line in f:
            if line.startswith("#"):
                continue

            parts = line.strip().split("\t")
            ref = parts[3]
            alt = parts[4]
            filt = parts[6]

            counts["total"] += 1

            if filt == "PASS":
                counts["pass"] += 1
            else:
                counts["filtered"] += 1

            alts = alt.split(",")

            has_snp = any(len(ref) == 1 and len(a) == 1 for a in alts)
            has_indel = any(len(ref) != len(a) for a in alts)

            if has_snp:
                counts["snp"] += 1
            if has_indel:
                counts["indel"] += 1

    return counts


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-vcf", required=True)
    parser.add_argument("--filtered-vcf", required=True)
    parser.add_argument("--pass-vcf", required=True)
    parser.add_argument("--output-json", default="metrics.json")
    parser.add_argument("--output-plot", default="variant_comparison.png")
    args = parser.parse_args()

    raw = count_variants(args.raw_vcf)
    passed = count_variants(args.pass_vcf)
    filtered_all = count_variants(args.filtered_vcf)

    metrics = {
        "raw_total": raw["total"],
        "raw_snps": raw["snp"],
        "raw_indels": raw["indel"],
        "pass_total": passed["total"],
        "pass_snps": passed["snp"],
        "pass_indels": passed["indel"],
        "filtered_total": raw["total"] - passed["total"],
        "filtered_percent": round((raw["total"] - passed["total"]) / raw["total"] * 100, 2),
        "filter_status_counts": {}
    }

    with open_vcf(args.filtered_vcf) as f:
        for line in f:
            if line.startswith("#"):
                continue
            filt = line.strip().split("\t")[6]
            metrics["filter_status_counts"][filt] = metrics["filter_status_counts"].get(filt, 0) + 1

    with open(args.output_json, "w") as out:
        json.dump(metrics, out, indent=2)

    df = pd.DataFrame({
        "Pre filtriranja": [metrics["raw_snps"], metrics["raw_indels"]],
        "Posle filtriranja": [metrics["pass_snps"], metrics["pass_indels"]]
    }, index=["SNP", "INDEL"])

    ax = df.plot(kind="bar", figsize=(8, 5))
    ax.set_ylabel("Broj varijanti")
    ax.set_title("Poređenje SNP i INDEL varijanti pre i posle filtriranja")
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.savefig(args.output_plot, dpi=150)


if __name__ == "__main__":
    main()
